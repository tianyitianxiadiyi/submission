import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import my_function as mf  # 这里是导入自定义函数。

# 首先是导入数据。
data = pd.read_csv('./points.txt', header=None)
data = np.array(data)
print(data.shape)

# 选取初始点，直接去前面k个作为初始点。
k = 8
middle = mf.choose_function(data, k)  # 这里是选取前7个样本点作为聚类的初始点
print(middle)

cnt = 1000
for i in range(cnt):  # 总共聚类cnt次
    lable = mf.distance_function(data, middle, k)  # 首先是提取出标签，也就是每个样本点的原始标签。
    lable = np.expand_dims(lable, axis=1)  # 增加维度
    x_y = np.column_stack((data, lable))  # 将数据合并
    middle = mf.upd_function(x_y, middle, k)  # 这里将聚类中心带你进行更新，

mf.v_function(x_y)  # 进行数据可视化
