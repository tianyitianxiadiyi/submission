import numpy as np
import matplotlib.pyplot as plt


def distance_function(data, data1, k):  # data是带着分类的数据，data1表示的是聚类点。
    ff = np.zeros([788, k])
    # print(ff)
    for i in range(k):
        t = data - data1[i, :]
        t1 = np.sum(t ** 2, axis=1, keepdims=True)
        # print(t1)
        ff[:, i] = np.sum(t ** 2, axis=1)
    label = np.argmin(ff, axis=1)
    return label


# 更新中心点。
def upd_function(data, middle, k):  # 将标签和原始数据传进去
    av_data = np.zeros_like(middle)
    for i in range(k):
        t = data[data[:, 2] == i]
        n, m = t.shape
        # print(np.sum(t[:,0:2],axis = 0)/n)
        av_data[i, :] = np.sum(t[:, 0:2], axis=0) / n
    return av_data  # 返回的是聚类点。


# 2.2 选取k个聚类点
def choose_function(data, k):
    np.random.seed(2233)  # 这里是设置随机数种子，保证后续结果一致。
    list_data = list(data)  # 首先先转化为列表的形式。
    for i in range(100):
        np.random.shuffle(list_data)  # 直接打乱顺序
    a = list_data[0:k]
    a = np.array(a)
    return a


def v_function(x_y):  # 数据可视化函数。
    # 数据可视化。
    plt.figure(figsize=(12, 8))
    plt.scatter(x_y[x_y[:, 2] == 0][:, 0], x_y[x_y[:, 2] == 0][:, 1])
    plt.scatter(x_y[x_y[:, 2] == 1][:, 0], x_y[x_y[:, 2] == 1][:, 1])
    plt.scatter(x_y[x_y[:, 2] == 2][:, 0], x_y[x_y[:, 2] == 2][:, 1])
    plt.scatter(x_y[x_y[:, 2] == 3][:, 0], x_y[x_y[:, 2] == 3][:, 1])
    plt.scatter(x_y[x_y[:, 2] == 4][:, 0], x_y[x_y[:, 2] == 4][:, 1])
    plt.scatter(x_y[x_y[:, 2] == 5][:, 0], x_y[x_y[:, 2] == 5][:, 1])
    plt.scatter(x_y[x_y[:, 2] == 6][:, 0], x_y[x_y[:, 2] == 6][:, 1])
    plt.scatter(x_y[x_y[:, 2] == 7][:, 0], x_y[x_y[:, 2] == 7][:, 1])
    plt.savefig("./给定数据集初始化点.png", dpi=600)  # 保存图片 注意 在show()之前  不然show会重新创建新的 图片
    plt.show()
