# 这里是梯度下降法。
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import my_function as mf  # 这里面有我自己定义的函数。

train_data = pd.read_csv('./data/train_.csv')  # 这里可以看到是相对路径，不是绝对路径。
# print(train_data)
[n, m] = train_data.shape  # 矩阵的大小导入到n和m的变量里面去，
# 求解每一列的平均值。
tr_data = train_data.iloc[:, 1:m]  # 切片 ，将数据复制一份。
mean_data = tr_data.mean(axis=0)  # 求解每一行的平均值，自动忽略缺失值。0表示列操作，1表示行操作。
[n1, m1] = tr_data.shape
for i in range(m1):
    tr_data.iloc[:, i:i + 1] = tr_data.iloc[:, i:i + 1].fillna(mean_data.iloc[i])
    # 这里要特别注意的是，确实值处理的那一列数据要赋值，同时做出切片操作的时候要多切一位，保证数据还是数据框结构。
# print(tr_data)
# print('矩阵的大小是：' + str(train_data.shape))  # 这里来看一下矩阵的大小。
# 标准化。
z_data_x = np.mat(tr_data.iloc[:, 0:m1 - 1])

z_data_y = np.mat(tr_data.iloc[:, m1 - 1:m1])  # 转化为矩阵。
# print(z_data_x.shape)
z_x1 = mf.z_score(z_data_x, 0)  # 调用自定义函数。
# print(z_data_x)
# print(z_x1)
z_x1 = pd.DataFrame(z_x1)
one_data = np.ones([n1, 1])
# z_x1.to_csv('./标准化后的数据(自变量）.csv')  # 这里引入中间变量来进行数据的存储非常重要，不然可能会出现一些致命的错误。

# 这里要特别注意的就是，现在z_x已经是数据框了，要先转化成矩阵的形式。
z_x = np.mat(z_x1)
z_x = np.hstack((z_x1, one_data))  # 这里是引入截距项。
# print(z_x)
[n4, m4] = z_x.shape
# print(n4)
# print(m4)
theta = np.zeros([m4, 1])  # 创造一个列向量并初始化为0，为后续迭代做准备。
alpha = 0.001  # 在这里定义学习速率，学习速率是加快迭代速度的，但是也不能太大。
lamda = 50  # 在这里定义lamda也就是正则化，惩罚项。

# 接下来就是求解最终的系数
# def iterate_function(alpha,cnt,theta,x,y)
cnt = 1500  # 这里选择的是迭代次数
finish, j_data = mf.iterate_function(alpha, lamda, cnt, theta, z_x, z_data_y)  # 返回的是系数以及代价函数随迭代次数的变化。
data = pd.DataFrame(finish)
# print(data)
# data.to_csv('./梯度下降法求得的系数.csv')

# 这里是数据可视化。
j_data = np.squeeze(j_data)  # 数据将维度
mf.myplot(cnt, j_data)

# 首先还是到输入数据。
# 这里数据预处理和上面一致，这里就不过多的赘述。
test_data = pd.read_csv('./data/test_.csv')
# print(test_data)

[n2, m2] = test_data.shape
test_x = test_data.iloc[:, 1:m2]  # 这里是切片。
# print(test_x)

[n2, m2] = test_x.shape  # 这里将n2,m2重置了。
mean_data1 = test_x.mean(axis=0)
# print('每一列的平均值是：\n' + str(mean_data1))

for i in range(m2):
    test_x.iloc[:, i:i + 1] = test_x.iloc[:, i:i + 1].fillna(mean_data1.iloc[i])
# print(test_x)
test_x = np.mat(test_x.iloc[:])  # 全部的切片 在这里先转化
one_data1 = np.ones([n2, 1])  # 创造1矩阵。
test_x = np.hstack((test_x, one_data1))  # 这里是二维的，所以要两个括号。
# 最后就是将验证集的数据代入然后进行求解。
print(test_x.shape)  # 这里回顾一下前面验证正规矩阵法的时候的数据集。
# print(finish)
[n6, m6] = test_x.shape

z_test = mf.z_score(test_x[:, 0:m6 - 1], 0)  # 将数据进行标准化。、
z_test = np.hstack((z_test, one_data1))  # 在数据后面加上1.
data = np.dot(z_test, finish)
data = pd.DataFrame(data)  # 转化为数据框。
print(data)
# data.to_csv('./梯度下降法.csv')
