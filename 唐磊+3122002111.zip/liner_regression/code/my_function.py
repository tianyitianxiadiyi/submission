# 这里是自定义函数。
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# 1.标准化的函数。
def z_score(data, a):  # 这里data表示的是那个二维数组或矩阵，a表示的是对行还是对列。
    [n, m] = data.shape
    mean_data1 = np.mean(data, axis=a).T  # 弄出来的时候是行向量。这里要特别注意的就是行向量和列向量之间的差距。
    std_data = np.std(data, axis=a).T  # 这里转置一下。
    # print(mean_data1[0,1])
    for i in range(m):
        data[:, i] = (data[:, i] - mean_data1[i, 0]) * (1 / std_data[i, 0])
    return data  # 返回data，data就是标准化后的矩阵。


def cost_function(theta, lamda, x, y):  # 这里表示的是将theta,lamda,x,y矩阵全部传进来，然后可以进行运算了。
    [n, m] = x.shape  # 查看数据的大小，为后续做准备。
    a = 1 / (2 * m)  # 首先将前面的1/(2m)定义出来 要注意括号的问题。
    b = np.dot(x, theta) - y  # 将代价函数与真实值作差。
    t = np.array(theta)  # 转化为矩阵的形式
    c = lamda / (2 * m) * sum(t ** 2)  # 加入惩罚项。
    return np.squeeze(a * np.dot(b.T, b) + c)  # 这里用矩阵的形式来表达平方项并消除维度的影响。


def der_function(theta, lamda, x, y):  # 对于线性函数 这个求导还是很好搞出来的。和上面是一样的参数传入。
    [n, m] = x.shape  # 首先还是要查看一下矩阵x的大小
    a = 1 / m  # 首先还是先定义1/m.
    b = np.dot(x, theta) - y  # 这里表示的是求和。
    c = lamda * theta  # 这里是创造惩罚项
    return a * (np.dot(x.T, b) + c)  # 最后返回的是一个求偏导的矩阵，全部都乘了1/m。


# 这个函数的参数依次是学习率，迭代次数，系数，自变量矩阵以及因变量。
def iterate_function(alpha, lamda, cnt, theta, x, y):  # 这里是迭代的函数，也是最重要的函数。
    y_data = []  # 创造一个空列表 用于储存数据。

    for i in range(cnt):  # 这里书写一个循环来表示迭代多少次。
        theta = theta - alpha * der_function(theta, lamda, x, y)  # 这里是函数里面继续调用函数
        j_data = cost_function(theta, lamda, x, y)  # 这里将代价函数的值返回
        y_data.append(j_data)  # 将每次代价函数的值储存起来。

    return theta, y_data  # 将theta和用于数据可视化的值返回。


def myplot(cnt, y):  # 这里传入的数字是指迭代多少次以及将迭代好的代价函数的值传入，便于画出图像。
    x = [x for x in range(len(y))]  # 这里首先创造一个迭代次数的列表。
    plt.plot(x, y, 'b-')
