# 这里是线性回归中正规矩阵法的代码。
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

train_data = pd.read_csv('./data/train_.csv')  # 这里可以看到是相对路径，不是绝对路径。
# print(train_data)
[n, m] = train_data.shape  # 矩阵的大小导入到n和m的变量里面去，
print('矩阵的大小是：' + str(train_data.shape))  # 这里来看一下矩阵的大小。
# 求解每一列的平均值。
tr_data = train_data.iloc[:, 1:m]  # 切片 ，将数据复制一份。
mean_data = tr_data.mean(axis=0)  # 求解每一行的平均值，自动忽略缺失值。0表示列操作，1表示行操作。
[n1, m1] = tr_data.shape
print('tr_data的大小是' + str(tr_data.shape))
for i in range(m1):
    tr_data.iloc[:, i:i + 1] = tr_data.iloc[:, i:i + 1].fillna(mean_data.iloc[i])
    # 这里要特别注意的是，确实值处理的那一列数据要赋值，同时做出切片操作的时候要多切一位，保证数据还是数据框结构。
print(tr_data)  # 查看数据。

# tr_data.to_csv('./处理缺失值后的数据.csv')  # 将数据导出。
# 这里将数据全部转化为矩阵的形式。
x = np.mat(tr_data.iloc[:, 0: m1 - 1])
y = np.mat(tr_data.iloc[:, m1 - 1: m1])
one_data = np.ones([n1, 1])
# print(z_data)
x = np.hstack((x, one_data))  # 这里将1矩阵放在最前面，那么最后的beta系数第一个就是截距项。
# print(x.shape)
# 这里将数据全部取出以后，使用矩阵的运算来进行ols多元线性回归。
# np. linalg.inv (a)
X = np.linalg.inv(np.dot(x.T, x))  # 先将x和x相乘的逆矩阵储存起来。
X1 = np.dot(X, x.T)  # 这里进行下一步的操作。
beta = np.dot(X1, y)
beta1 = pd.DataFrame(beta)  # 转化为数据框。
print('系数如下（最后的为截距项，剩余的按照顺序为标签前面的系数）：')
print(beta1)
# beta1.to_csv('./截距项与各个自变量的偏导.csv')  # 导出文件。

# 首先还是到输入数据。
# 这里数据预处理和上面一致，这里就不过多的赘述。
test_data = pd.read_csv('./data/test_.csv')
# print(test_data)

[n2, m2] = test_data.shape
test_x = test_data.iloc[:, 1:m2]  # 这里是切片。
# print(test_x)

[n2, m2] = test_x.shape  # 这里将n2,m2重置了。
mean_data1 = test_x.mean(axis=0)
print('每一列的平均值是：\n' + str(mean_data1))

for i in range(m2):
    test_x.iloc[:, i:i + 1] = test_x.iloc[:, i:i + 1].fillna(mean_data1.iloc[i])
# print(test_x)
test_x = np.mat(test_x.iloc[:])  # 全部的切片 在这里先转化
one_data1 = np.ones([n2, 1])  # 创造1矩阵。
test_x = np.hstack((test_x, one_data1))  # 这里是二维的，所以要两个括号。
test_y = np.dot(test_x, beta)  # 这里将矩阵相乘即可得到对于的因变量。
test_y = pd.DataFrame(test_y)
print(test_y)
# test_y.to_csv('./正规矩阵法.csv')

