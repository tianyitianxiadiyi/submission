# 这里是自定义函数。
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# 归一化函数。
def max_min(X):  # 这里传入的是一个矩阵，也就是一个像素点矩阵。
    return X / 255  # 将每个像素点全部除以255,进行归一化处理。


# 这里是激活函数
def softmax_function(x):  # 这里传入的是一个矩阵
    max_data = np.max(x, axis=1)  # 这里直接找出每一行的最大值。
    # print(max_data)
    x = x.T  # 这里要转置一下，十分重要！吃了大亏，因为上面那个max_data是行向量。
    ex = x - max_data  # 这里直接把数据相减
    finish = np.exp(ex) / np.sum(np.exp(ex), axis=0)  # 这里由于矩阵已经转置过来了，就正常操作。
    return finish.T  # 将最终的结果返回。


# 计算损失值的函数：
def loss_function(y, y_pre):  # 这里只要计算输出层的那个损失值即可，也就是说是softmax函数那一层的东西。
    # 这里传入的是one-hor编码。
    loss = - np.mean(np.log(y * y_pre + 1e-7))  # 直接使用one-hot编码来计算损失值，比for循环快,。
    return loss


# # 正向传播：
# def sigmoid_forward(X, w1, b1):
#     a1 = np.dot(X, w1) + b1  # 先将参数转化为线性模式,这里要注意的就是这个权重的问题。
#     # print(a1)                   # 这里的参数调整有点微妙反正就是。
#     z1 = sigmoid_function(a1)  # 转化为sigmoid形式。
#     return z1, a1  # 返回一个矩阵。
#
#
def softmax_reverse(y, y_pre, num, z1):  # 首先传入的是一个one-hot编码 这个十分重要。然后就是样本的总数和矩阵。
    dl_dz2 = y_pre - y  # 这里是损失函数对z2的求导。
    new_w = np.dot(z1.T, dl_dz2) / num  # 这里要使用的是链式求导法则，最终可以得到偏导数的矩阵。
    db = np.sum(dl_dz2, axis=0) / num  # 在这里表示函数对偏置项的偏导数,这里直接列项求和然后去平均。
    return new_w, db  # 这里要返回3个值。
