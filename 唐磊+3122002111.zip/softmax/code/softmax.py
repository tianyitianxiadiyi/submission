import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import my_function as mf

# 导入数据
data = pd.read_csv('./data/train.csv')  # 将数据储存。
[n, m] = data.shape  # 查看数据集的大小。
print(n, m)
soft_x = np.array(data.iloc[:, 2:m])  # 将特征全部提取出来。
soft_y = np.array(data.iloc[:, 1:2]).T
soft_y = np.squeeze(soft_y)  # 将y转化为一维矩阵便于后续操作。
# print(soft_x.shape)  # 查看数据有没有导入正确。
# print(soft_y)
# print(soft_x.shape)

[n, m] = soft_x.shape
# print(n, m)  # 将样本的数据提取出来。
Z_data = mf.max_min(soft_x)  # 将数据进行归一化。
# print(Z_data) # 这里Z_data表示的就是标准化后的数据。
one_hot_data = np.eye(10)[soft_y]
# print(one_hot_data)  # 转化为one-hot编码。

# 初始化。
np.random.seed(11)
w = 0.01 * np.random.rand(784, 10)
b = np.zeros(10)
cnt = 200
alpha = 0.01
loss = np.zeros(cnt)
for i in range(100):
    a = np.dot(Z_data, w) + b
    z = mf.softmax_function(a)

    loss[i] = mf.loss_function(one_hot_data, z)

    dw, db = mf.softmax_reverse(one_hot_data, z, 20000, Z_data)

    w -= alpha * dw
    b -= alpha * db
# print(w)
# print(b)

# 接下来就是对测试集进行验证。
test_data = pd.read_csv('./data/test_no_answer.csv')
# print(test_data)
[n, m] = test_data.shape
test_x = test_data.iloc[:, 1:m]  # 提取数据集。
# print(test_x.shape)
test_x = np.array(test_x)  # 这里转化为矩阵的形式。
Z_test = mf.max_min(test_x)  # 这里将数据归一化。
# print(Z_test)
test_a = np.dot(test_x, w) + b
test_z = mf.softmax_function(test_a)
finish = np.argmax(test_z, axis=1)
finish = pd.DataFrame(finish)
print(finish)
finish.index = np.arange(1, len(finish) + 1)
finish.to_csv('./最终分类结果.csv')
